<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="estilosVisor.css">
    <title>Visor</title>
</head>

<body>
    <table>
        <tr>
            <th>Nombre Completo</th>
            <th>Fecha de Nacimiento</th>
            <th>Dirección</th>
            <th>Ciudad</th>
            <th>Provincia</th>
            <th>Código Postal</th>
            <th>Número de Teléfono</th>
            <th>Correo Electrónico</th>
            <th>Profesión</th>
            <th>Situacion Laboral</th>
        </tr>
        <tr>
            <td id="nombre"><?php echo $_POST['nombre']; ?></td>
            <td id="fecha"><?php echo $_POST['fecha-nacimiento']; ?></td>
            <td id="direccion"><?php echo $_POST['direccion']; ?></td>
            <td id="ciudad"><?php echo $_POST['ciudad']; ?></td>
            <td id="provincia"><?php echo $_POST['provincia']; ?></td>
            <td id="codigo"><?php echo $_POST['codigo-postal']; ?></td>
            <td id="telefono"><?php echo $_POST['telefono']; ?></td>
            <td id="correo"><?php echo $_POST['email']; ?></td>
            <td id="profesion"><?php echo $_POST['ocupacion']; ?></td>
            <td id="profesion"><?php echo $_POST['situacion_laboral']; ?></td>
        </tr>
    </table>
    <table>
        <tr>
            <th>Estudios</th>
        </tr>
        <tr>
            <td id="nombre"><?php echo $_POST['comentarios']; ?></td>
        </tr>
    </table>
    <?php

    ?>
</body>

</html>