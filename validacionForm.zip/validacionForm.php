<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="estilos.css">
    <title>Formulario1</title>
</head>

<body>
    <h1>Formulario de Datos Personales</h1>
    <?php
    if (isset($_POST['submit'])) {
        $errores = [];

        if (empty($_POST['nombre'])) {
            $errores['nombre'] = "El campo nombre es obligatorio.";
        }
        if (empty($_POST['telefono'])) {
            $errores['telefono'] = "El campo teléfono es obligatorio.";
        }
        if (empty($_POST['email'])) {
            $errores['email'] = "El campo email es obligatorio.";
        }
        if (empty($_POST['ocupacion'])) {
            $errores['ocupacion'] = "El campo ocupación es obligatorio.";
        }
        if (empty($_POST['contrasena'])) {
            $errores['contrasena'] = "El campo contraseña es obligatorio.";
        }

        if (!empty($errores)) {
            foreach ($errores as $campo => $mensaje) {
                echo $mensaje . "<br>";
            }
        } else {
    ?>
        <table border="3px" align="center">
            <tr>
                <td id="nombre"><?php echo $_POST['nombre']; ?></td>
                <td id="telefono"><?php echo $_POST['telefono']; ?></td>
                <td id="correo"><?php echo $_POST['email']; ?></td>
                <td id="profesion"><?php echo $_POST['ocupacion']; ?></td>
                <td id="profesion"><?php echo $_POST['contrasena']; ?></td>
            </tr>
        </table>
    <?php
        }
    }
    ?>
    <form action="validacionForm.php" method="post" enctype="multipart/form-data">
        <label for="nombre">Nombre Completo*:</label><br>
        <input type="text" id="nombre" name="nombre"><br><br>

        <label for="telefono">Número de Teléfono*:</label><br>
        <input type="tel" id="telefono" name="telefono"><br><br>

        <label for="email">Correo Electrónico*:</label><br>
        <input type="email" id="email" name="email"><br><br>

        <label for="ocupacion">Profesion*:</label><br>
        <input type="text" id="ocupacion" name="ocupacion"><br><br>

        <label for="contrasena">Contraseña Sitio Web*:</label><br>
        <input type="password" id="contrasena" name="contrasena"><br><br>

        <input type="submit" value="Enviar" name="submit">
    </form>

</body>

</html>